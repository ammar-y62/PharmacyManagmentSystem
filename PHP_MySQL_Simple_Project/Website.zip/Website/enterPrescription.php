<form action="addPrescription.php" method="post">
   Prescription ID: <input type="text" name="prescriptionID"><br>
   Date: <input type="text" name="date"><br>
   Workflow State: <input type="text" name="workflow_state"><br>
   PHN: <input type="text" name="PHN"><br>
   SSN: <input type="text" name="SSN"><br>
   Licence Number: <input type="text" name="LicenceNumber"><br>
   Delivery ID: <input type="text" name="DeliveryID"><br>
   DIN: <input type="text" name="DIN"><br>
   Quantity: <input type="text" name="Quantity"><br>
   <input type="submit" value="add">
</form>