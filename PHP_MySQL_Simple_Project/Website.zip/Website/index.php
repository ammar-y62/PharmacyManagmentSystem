
<html>
<body>

<form action="validate.php" method="post">
   Username: <input type="text" name="username"><br>
   Password: <input type="text" name="password"><br>
   <input type="submit" value="Log In">
</form>

</body>
</html>
