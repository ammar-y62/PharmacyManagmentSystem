<form action="addPatient.php" method="post">
  PHN: <input type="text" name="PHN"><br>
  Address: <input type="text" name="Address"><br>
  First Name: <input type="text" name="FirstName"><br>
  Last Name: <input type="text" name="LastName"><br>
  Phone Number: <input type="text" name="PhoneNumber"><br>
  Date Of Birth: <input type="text" name="DateOfBirth"><br>
   <input type="submit" value="add">
</form>