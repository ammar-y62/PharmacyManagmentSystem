<?php
//include'';                                                              //which file???????
// Create connection
$con=mysqli_connect("localhost","root","","471");

// Check connection
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//if you click on search button
if (isset($_POST['search'])){
    $search = $_POST['search'];
    $sql = "SELECT * FROM APPOINTMENT WHERE Time = '$search' ";            // are we going to search by Time or SSN or PHN or any of them??????
    /*or PHN = '$search' or SSN = '$search';*/
    $result = mysqli_query($con);
    // if successfully excuted
    if($result){
        //if number of rows greater than zero
        if(mysqli_num_rows($result)>0){
            //display table head 
            echo '<thead>
            <tr>
            <th>Time</th>
            <th>Type</th>
            <th>SSN</th>
            <th>PHN</th>
            </tr>
            </thead>';
            while($row = mysqli_fetch_assoc($result)){
            //desplaying inside table row
            echo '<tbody>
            <tr>
            <td>'.$row['Time'].'</td>
            <td>'.$row['Type']'</td>
            <td>'.$row['SSN'].'</td>
            <td>'.$row['PHN'].'</td>
            </tr>
            </tbody>';
            }
        }
        else{
            //no data or wrong input (rows < 0)
            echo '<h2 class = text-danger>Data not found</h2>';
        }
    }
    if(isset($_GET['delete'])){
        $delete = $_GET['delete'];
        $sql = "DELETE * FROM APPOINTMENT WHERE Time = '$delete'"; // are we going to search by Time or SSN or PHN or any of them??????
        // do i need to create new variables or is it okay to use the same variables.
        $result = mysqli_query($con,$sql);
        // if($result){
        //     // echo "Deleted successfully";
        //     header('location:display.php'); //make sure which file is the correct php file.(the file that displays the button)
        // }
        // else{
        //     die(mysqli_error($con)); 
        // }
    }
    $id = $_GET['updateid'];
    $sql = "SELECT * from APPOINTMENT where id =$id";
    $result = mysqli_query($con,$sql);
    $row = mysqli_fetch_assoc($result);
    if (isset($_POST['submit'])){
        $Time = $_POST['Time'];
        $Type = $_POST['Type'];
        $SSN = $_POST['SSN'];
        $PHN = $_POST['PHN'];
        $sql = "UPDATE APPOINTMENT SET id =$id, Time = '$Time', Type = '$Type', SSN = '$SSN', PHN = '$PHN' WHERE id=$id";
        $result = mysqli_query($con,$sql);
        if($result){
            echo "updated successfully";
        }
        else{

        }
    }

    
}
?>
