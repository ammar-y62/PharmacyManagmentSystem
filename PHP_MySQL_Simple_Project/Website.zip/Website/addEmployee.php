<?php
$SSN = $_POST["SSN"];
$First_Name = $_POST["FirstName"];
$Last_Name = $_POST["LastName"];
$Address = $_POST["Address"];
$Salary = $_POST["Salary"];
$Phone_number = $_POST["PhoneNumber"];
$Username = $_POST["Username"];
$Password = $_POST["password"];
$Job_type = $_POST["jobtype"];
// Create connection
$con=mysqli_connect("localhost","root","","471");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql = "INSERT INTO EMPLOYEE VALUES ('$SSN', '$First_Name', '$Last_Name', '$Address', '$Salary', '$Phone_number', '$Username', '$Password', '$Job_type')"; 
mysqli_query($con, $sql);

@include("validate.php");
?>