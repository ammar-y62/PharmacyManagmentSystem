<form action="addPatientAllergy.php" method="post">
  PHN: <input type="text" name="PHN"><br>
  Allergy: <input type="text" name="Allergy"><br>
   <input type="submit" value="add">
</form>