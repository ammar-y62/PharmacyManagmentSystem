<form action="addInventoryItem.php" method="post">
  DIN: <input type="text" name="DIN"><br>
  Name: <input type="text" name="Name"><br>
  Cost Per Unit: <input type="text" name="Cost_per_Unit"><br>
  Min Allowable: <input type="text" name="MinAllowable"><br>
  Max Allowable: <input type="text" name="MaxAllowable"><br>
  Info: <input type="text" name="Info"><br>
  Quantity On Hand: <input type="text" name="QuantityOnHand"><br>
   <input type="submit" value="add">
</form>