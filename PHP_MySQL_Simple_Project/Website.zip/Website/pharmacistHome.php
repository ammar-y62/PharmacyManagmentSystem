echo "Prescriptions ready for verification: ";

//code to display all prescriptions in the verify state 

<form action="updateDeleteFollowup.php" method="post">
   Search for Followup: <input type="text" name="followup"><br>
   <input type="submit" value="search">
</form>

<form action="enterFollowup.php" method="post">
   <input type="submit" value="Add Followup">
</form>

<form action="updateDeleteVaccineRecord.php" method="post">
   Search for Vaccine Record: <input type="text" name="vaccineRecord"><br>
   <input type="submit" value="search">
</form>
<form action="enterVaccineRecord.php" method="post">
   <input type="submit" value="Add Vaccine Record">
</form>

<form action="index.php" method="post">
   <input type="submit" value="Log Out">
</form>
