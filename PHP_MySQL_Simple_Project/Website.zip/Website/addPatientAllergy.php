<?php
$PHN = $_POST["PHN"];
$Allergy = $_POST["Allergy"];
// Create connection
$con=mysqli_connect("localhost","root","","471");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql = "INSERT INTO PATIENT_ALLERGY VALUES ('$PHN', '$Allergy')"; 

mysqli_query($con, $sql);

@include("validate.php");
?>