<form action="addFollowup.php" method="post">
  Date: <input type="text" name="Date"><br>
  Notes: <input type="text" name="Notes"><br>
  Patient SSN: <input type="text" name="patientSSN"><br>
  Prescription ID: <input type="text" name="prescriptionID"><br>
   <input type="submit" value="add">
</form>