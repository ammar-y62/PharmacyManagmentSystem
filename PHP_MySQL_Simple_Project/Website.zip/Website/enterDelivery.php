<form action="addDelivery.php" method="post">
   Delivery ID: <input type="text" name="DeliveryID"><br>
   Shipping Date: <input type="text" name="Shipping_Date"><br>
   Delivery Date: <input type="text" name="Delivery_Date"><br>
   Confirmation: <input type="text" name="Confirmation"><br> <!-- Why??-->
   <input type="submit" value="add">
</form>