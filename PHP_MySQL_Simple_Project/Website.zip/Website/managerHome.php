<form action="searchInventoryItem.php" method="post">
   Search for Inventory Item: <input type="text" name="inventoryItem"><br>
   <input type="submit" value="search">
</form>

<form action="enterInventoryItem.php" method="post">
   <input type="submit" value="Add Inventory Item">
</form>

<form action="deleteInventoryItem.php" method="post">
   DIN: <input type="text" name="DIN"> <br>
   <input type="submit" value="Delete Inventory Item by DIN">
</form>
<form action="updateInventoryItem.php" method="post">
   <input type="submit" value="Update Inventory Item by DIN">
</form>

<form action="index.php" method="post">
   <input type="submit" value="Log Out">
</form>

<form action="displayEmployeeInfo.php" method="post">
   <input type="submit" value="Display Employee Info">
</form>