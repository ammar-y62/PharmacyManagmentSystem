<form action="addEmployee.php" method="post">
  SSN: <input type="text" name="SSN"><br>
  First Name: <input type="text" name="FirstName"><br>
  Last Name: <input type="text" name="LastName"><br>
  Address: <input type="text" name="Address"><br>
  Salary: <input type="text" name="Salary"><br>
  Phone Number: <input type="text" name="PhoneNumber"><br>
  Username: <input type="text" name="Username"><br>
  Password: <input type="text" name="password"><br>
  Job Type: <input type="text" name="jobtype"><br>
   <input type="submit" value="add">
</form>