<!-- Do we need this -->
<form action="addVaccineRecord.php" method="post">
   DIN: <input type="text" name="DIN"><br>
   Date: <input type="text" name="Date"><br>
   Pharmacist SSN: <input type="text" name="pharmacistSSN"><br>
   Dose Number: <input type="text" name="DoseNumber"><br>
   <input type="submit" value="add">
</form>