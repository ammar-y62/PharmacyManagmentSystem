

<form action="updateDeletePatient.php" method="post">
   Search for Patient: <input type="text" name="patient"><br>
   <input type="submit" value="search">
</form>

<form action="enterPatient.php" method="post">
   <input type="submit" value="Add Patient">
</form>

<form action="updateDeleteAppointment.php" method="post">
   Search for Appointment: <input type="text" name="appointment"><br>
   <input type="submit" value="search">
</form>

<form action="enterAppointment.php" method="post">
   <input type="submit" value="Add Appointment">
</form>

<form action="updateDeletePrescription.php" method="post">
   Search for Prescription: <input type="text" name="prescription"><br>
   <input type="submit" value="search">
</form>

<form action="enterPrescription.php" method="post">
   <input type="submit" value="Add Prescription">
</form>

<form action="updateDeleteDelivery.php" method="post">
   Search for Delivery: <input type="text" name="delivery"><br>
   <input type="submit" value="search">
</form>

<form action="enterDelivery.php" method="post">
   <input type="submit" value="Add Delivery">
</form>

<form action="updateDeleteDoctor.php" method="post">
   Search for Doctor: <input type="text" name="doctor"><br>
   <input type="submit" value="search">
</form>
<form action="enterDoctor.php" method="post">
   <input type="submit" value="Add Doctor">
</form>

<form action="index.php" method="post">
   <input type="submit" value="Log Out">
</form>
