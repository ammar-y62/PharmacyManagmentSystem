<?php
// Create connection
$con=mysqli_connect("localhost","root","","471");

// Check connection
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$inventoryItem = $_POST["inventoryItem"];
$sql = "SELECT * FROM `INVENTORY_ITEM` WHERE DIN = '$inventoryItem'";

$select_item = mysqli_query($con, $sql);
$fetch_item = mysqli_fetch_assoc($select_item);

$din = $fetch_item['DIN'];
$name = $fetch_item['Name'];
$cost = $fetch_item['Cost_per_item'];
$minallowable = $fetch_item['Min_allowable'];
$maxallowable = $fetch_item['Max_allowable'];
$info = $fetch_item['Info'];
$Quantity = $fetch_item['Quantity_on_hand'];

$sql = "UPDATE INVENTORY_ITEM VALUES ('$din', '$name', $cost, $minallowable, $maxallowable, '$info', $Quantity)"; 
$select_item = mysqli_query($con, $sql);


// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql = "UPDATE INVENTORY_ITEM VALUES ('$din', '$name', $cost, $minallowable, $maxallowable, '$info', $Quantity)"; 

mysqli_query($con, $sql);

@include("managerHome.php");
?>