<form action="addAppointment.php" method="post">
   Date: <input type="text" name="date"><br>
   Time: <input type="text" name="time"><br>
   Type: <input type="text" name="type"><br>
   SSN: <input type="text" name="SSN"><br>
   PHN: <input type="text" name="PHN"><br>
   <input type="submit" value="add">
</form>
