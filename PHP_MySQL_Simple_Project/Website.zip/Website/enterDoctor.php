<form action="addDoctor.php" method="post">
  LicenseNumber: <input type="text" name="LicenseNumber"><br>
  Speciality: <input type="text" name="Speciality"><br>
  First Name: <input type="text" name="FirstName"><br>
  Last Name: <input type="text" name="LastName"><br>
  Phone Number: <input type="text" name="PhoneNumber"><br>
  Office Address: <input type="text" name="OfficeAddress"><br>
   <input type="submit" value="add">
</form>